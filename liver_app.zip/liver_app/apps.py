from django.apps import AppConfig


class LiverAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'liver_app'
