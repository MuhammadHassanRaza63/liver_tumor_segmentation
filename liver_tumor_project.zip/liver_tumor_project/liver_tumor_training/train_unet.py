import os
import numpy as np
import tensorflow as tf
from tensorflow.keras import layers, models
from sklearn.model_selection import train_test_split
from tqdm import tqdm
import cv2
import nibabel as nib  

# CONFIGURATION 
IMG_SIZE = 256
MAX_SLICES = 100  
CT_SCAN_DIR = r'D:\liver_tumor_project\liver_tumor_project\liver_tumor_training\ct_scan'
SEGMENTATION_DIR = r'D:\liver_tumor_project\liver_tumor_project\liver_tumor_training\segmentations'
MODEL_SAVE_PATH = r'D:\liver_tumor_project\model.h5'

# Ensure save directory exists
os.makedirs(os.path.dirname(MODEL_SAVE_PATH), exist_ok=True)

# LOAD DATA
def load_data():
    print("🔄 Loading data...")
    images, masks = [], []
    volume_files = sorted(os.listdir(CT_SCAN_DIR))

    for vol_file in tqdm(volume_files, desc="📂 Reading volumes"):
        vol_path = os.path.join(CT_SCAN_DIR, vol_file)
        seg_path = os.path.join(SEGMENTATION_DIR, vol_file.replace('volume', 'segmentation'))

        try:
            ct_volume = nib.load(vol_path).get_fdata().astype(np.float32)
            seg_volume = nib.load(seg_path).get_fdata().astype(np.float32)
        except Exception as e:
            print(f"⚠️ Skipping {vol_file} due to error: {e}")
            continue

        for i in range(ct_volume.shape[-1]):
            img_slice = ct_volume[:, :, i]
            mask_slice = seg_volume[:, :, i]

            if np.sum(mask_slice) == 0:
                continue

            img_resized = cv2.resize(img_slice, (IMG_SIZE, IMG_SIZE))
            mask_resized = cv2.resize(mask_slice, (IMG_SIZE, IMG_SIZE))

            img_resized = img_resized.astype(np.float32) / 255.0
            mask_resized = (mask_resized > 0).astype(np.float32)

            images.append(img_resized[..., np.newaxis])
            masks.append(mask_resized[..., np.newaxis])

            if MAX_SLICES and len(images) >= MAX_SLICES:
                break

        if MAX_SLICES and len(images) >= MAX_SLICES:
            break

    print(f"✅ Data loaded: {len(images)} slices")
    return np.array(images), np.array(masks)

# U-NET ARCHITECTURE
def build_unet(input_size=(IMG_SIZE, IMG_SIZE, 1)):
    inputs = layers.Input(input_size)

    def conv_block(x, filters):
        x = layers.Conv2D(filters, 3, activation='relu', padding='same')(x)
        x = layers.Conv2D(filters, 3, activation='relu', padding='same')(x)
        return x

    def encoder_block(x, filters):
        f = conv_block(x, filters)
        p = layers.MaxPooling2D((2, 2))(f)
        return f, p

    def decoder_block(x, skip, filters):
        us = layers.UpSampling2D((2, 2))(x)
        concat = layers.Concatenate()([us, skip])
        return conv_block(concat, filters)

    f1, p1 = encoder_block(inputs, 32)
    f2, p2 = encoder_block(p1, 64)
    f3, p3 = encoder_block(p2, 128)
    f4, p4 = encoder_block(p3, 256)

    bottleneck = conv_block(p4, 512)

    d1 = decoder_block(bottleneck, f4, 256)
    d2 = decoder_block(d1, f3, 128)
    d3 = decoder_block(d2, f2, 64)
    d4 = decoder_block(d3, f1, 32)

    outputs = layers.Conv2D(1, 1, activation='sigmoid')(d4)

    model = models.Model(inputs, outputs)
    return model

# DICE COEFFICIENT
def dice_coef(y_true, y_pred):
    smooth = 1.0
    y_true_f = tf.reshape(y_true, [-1])
    y_pred_f = tf.reshape(y_pred, [-1])
    intersection = tf.reduce_sum(y_true_f * y_pred_f)
    return (2. * intersection + smooth) / (tf.reduce_sum(y_true_f) + tf.reduce_sum(y_pred_f) + smooth)

# MAIN TRAINING 
if __name__ == "__main__":
    print("🚀 Starting training pipeline...")

    X, Y = load_data()

    if len(X) == 0:
        print("❌ No valid slices loaded. Exiting...")
        exit()

    X_train, X_val, Y_train, Y_val = train_test_split(X, Y, test_size=0.1, random_state=42)

    print("🧠 Building model...")
    model = build_unet()
    model.compile(optimizer='adam', loss='binary_crossentropy', metrics=[dice_coef])
    model.summary()

    print("📈 Training model...")
    model.fit(X_train, Y_train, validation_data=(X_val, Y_val), batch_size=1, epochs=30)

    model.save(MODEL_SAVE_PATH)
    print(f"✅ Model training completed and saved as {MODEL_SAVE_PATH}")
