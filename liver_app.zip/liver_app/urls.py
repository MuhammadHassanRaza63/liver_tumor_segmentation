from django.urls import path
from . import views

urlpatterns = [
    path('', views.tumor_detection_view, name='tumor_detection'),
]
