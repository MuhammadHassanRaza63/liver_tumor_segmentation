import os
from django.shortcuts import render
from django.conf import settings
from .forms import UploadImageForm
from .unet_model.predict import predict_tumor
from .utils import generate_pdf_report

def tumor_detection_view(request):
    if request.method == 'POST':
        form = UploadImageForm(request.POST, request.FILES)
        if form.is_valid():
            patient_name = form.cleaned_data['patient_name']
            image = form.cleaned_data['image']
            image_name = image.name
            image_path = os.path.join(settings.MEDIA_ROOT, image_name)

            with open(image_path, 'wb+') as f:
                for chunk in image.chunks():
                    f.write(chunk)

            tumor_detected, result_image_path = predict_tumor(image_path)
            message = "✅ Tumor Region Detected" if tumor_detected else "❌ No Tumor Detected"

            pdf_name = f"report_{image_name.replace('.', '_')}.pdf"
            pdf_path = os.path.join(settings.MEDIA_ROOT, 'outputs', pdf_name)
            os.makedirs(os.path.dirname(pdf_path), exist_ok=True)

            generate_pdf_report(
                message=message,
                result_img_path=result_image_path,
                save_path=pdf_path,
                patient_name=patient_name
            )

            return render(request, 'result.html', {
                'message': message,
                'patient_name': patient_name,
                'uploaded_image': settings.MEDIA_URL + image_name,
                'predicted_image': settings.MEDIA_URL + 'outputs/' + os.path.basename(result_image_path),
                'pdf_link': settings.MEDIA_URL + 'outputs/' + os.path.basename(pdf_path),
            })
    else:
        form = UploadImageForm()

    return render(request, 'upload.html', {'form': form})