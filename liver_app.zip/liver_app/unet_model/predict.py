import os
import numpy as np
import cv2
from tensorflow.keras.models import load_model

# ✅ Load model from correct absolute path
model = load_model(r'D:\liver_tumor_project\model.h5')

def predict_tumor(image_path):
    image_gray = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if image_gray is None:
        raise FileNotFoundError(f"❌ Could not read image at path: {image_path}")

    original_shape = image_gray.shape
    image_resized = cv2.resize(image_gray, (256, 256))
    image_normalized = image_resized.astype(np.float32) / 255.0
    input_image = np.expand_dims(image_normalized, axis=(0, -1))

    pred_mask = model.predict(input_image)[0, :, :, 0]
    pred_mask = (pred_mask > 0.5).astype(np.uint8)
    pred_mask = cv2.resize(pred_mask, (original_shape[1], original_shape[0]))

    image_color = cv2.imread(image_path)
    if image_color is None:
        raise FileNotFoundError(f"❌ Could not read original image at path: {image_path}")

    mask_colored = cv2.cvtColor(pred_mask * 255, cv2.COLOR_GRAY2BGR)
    overlay = cv2.addWeighted(image_color, 0.7, mask_colored, 0.3, 0)

    output_name = f"result_{os.path.basename(image_path)}"
    output_path = os.path.join('media', 'outputs', output_name)
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    cv2.imwrite(output_path, overlay)

    return np.sum(pred_mask) > 0, output_path
