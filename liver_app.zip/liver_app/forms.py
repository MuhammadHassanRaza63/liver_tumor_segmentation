from django import forms

class UploadImageForm(forms.Form):
    patient_name = forms.CharField(label='Patient Name', max_length=100)
    image = forms.ImageField(label='Upload CT Scan Image')
